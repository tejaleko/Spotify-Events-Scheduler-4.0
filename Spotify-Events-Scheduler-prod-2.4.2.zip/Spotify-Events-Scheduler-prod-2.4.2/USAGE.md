# spotify-events-scheduler

1. Unzip `spotify-events-scheduler.zip`
2. Open chrome browser, go to chrome://extensions
3. Select "Load unzipped extensions" (The button on the left side of the screen under the search bar)
4. Then in the popup file selector, select the `dist` folder in the unzipped folder
5. You should see the extension appear in your extension library.
6. You can pin your extension to your browser extension bar on the right hand side of the chrome browser to test the icon (the icon has a white background so you may not be able to see it in the library)
7. Go to the gallery page (i.e https://studio.brightcove.com/products/videocloud/gallery/edit/5fd0ffd079f965a775f667d4/page/index), see if there's a "Spotify Events Scheduler" option on the left side menu (keep in mind that the plugin will only generate this option in gallery pages, basically any url that contains https://studio.brightcove.com/products/videocloud/gallery/edit/).
8. Click on "Spotify Events Scheduler", you should see the scheduler dialog pops up.